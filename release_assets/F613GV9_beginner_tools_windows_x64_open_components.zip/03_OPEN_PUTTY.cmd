@echo off
chcp 65001 >nul
title F613GV9 - 打开PuTTY Telnet
cd /d "%~dp0"
if not exist "putty.exe" (
  echo 找不到 putty.exe，请重新解压完整工具包。
  pause
  exit /b 1
)
start "" "%~dp0putty.exe" -telnet 192.168.1.1 23

