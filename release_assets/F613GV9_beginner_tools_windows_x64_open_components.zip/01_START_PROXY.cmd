@echo off
chcp 65001 >nul
title F613GV9 - HTTPS兼容代理（保持窗口打开）
cd /d "%~dp0"
echo.
echo 正在启动本项目HTTPS兼容代理。
echo 看到 listening 后不要关闭，继续双击 02_GET_TEMP_TELNET.cmd。
echo.
zte_https_compat_proxy.exe -listen 127.0.0.1:18080 -upstream https://192.168.1.1:443 -trim-aes-suffix
echo.
echo 代理已经退出。如果不是主动按 Ctrl+C，请回教程排查。
pause

