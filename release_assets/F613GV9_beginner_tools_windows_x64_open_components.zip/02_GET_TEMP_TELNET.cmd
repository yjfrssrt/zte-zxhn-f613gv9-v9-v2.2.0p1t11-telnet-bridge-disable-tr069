@echo off
chcp 65001 >nul
title F613GV9 - 获取临时Telnet
cd /d "%~dp0"
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp002_GET_TEMP_TELNET.ps1"

