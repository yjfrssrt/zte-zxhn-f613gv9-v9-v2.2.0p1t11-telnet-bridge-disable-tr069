﻿$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot

Write-Host '实验性工具：离线和真实响应回归已通过，但尚未完成下一次拔纤实机验证。' -ForegroundColor Yellow
Write-Host '如果你只按已验证主教程操作，请关闭本窗口，使用02脚本。' -ForegroundColor Yellow
$confirm = Read-Host '确认在自己拥有、已拔光纤、电脑直连的F613GV9上测试？输入 YES 继续'
if ($confirm -cne 'YES') {
    Write-Host '已取消。'
    exit 2
}

Get-NetAdapter | Format-Table Name, Status, MacAddress, LinkSpeed -AutoSize
$macInput = Read-Host '请输入直连有线网卡MAC（横线可保留）'
$mac = ($macInput -replace '[-:\s]', '').ToLowerInvariant()
if ($mac -notmatch '^[0-9a-f]{12}$') {
    throw 'MAC格式错误。'
}
$superUser = Read-Host '请输入超管用户名；直接回车使用 CMCCAdmin'
if ([string]::IsNullOrWhiteSpace($superUser)) {
    $superUser = 'CMCCAdmin'
}
$securePass = Read-Host '请输入超管密码（不会显示）' -AsSecureString
$plainPass = [Net.NetworkCredential]::new('', $securePass).Password
try {
    & "$PSScriptRoot\f613gv9_factory_telnet.exe" -mac $mac -username $superUser -password $plainPass
    $toolExit = $LASTEXITCODE
} finally {
    $plainPass = $null
    $securePass = $null
}
Read-Host '按回车关闭'
exit $toolExit

