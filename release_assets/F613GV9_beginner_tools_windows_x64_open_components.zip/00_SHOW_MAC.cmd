@echo off
chcp 65001 >nul
title F613GV9 - 查看有线网卡MAC
echo.
echo 找到状态为 Up、并且网线直连光猫的“以太网”。
echo 记下它的 MacAddress，后面输入时横线可以保留。
echo.
powershell.exe -NoLogo -NoProfile -Command "Get-NetAdapter | Format-Table Name,Status,MacAddress,LinkSpeed -AutoSize"
echo.
pause

