@echo off
chcp 65001 >nul
title F613GV9 - 实验性开源FactoryMode客户端
cd /d "%~dp0"
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp004_EXPERIMENTAL_OPEN_CLIENT.ps1"

