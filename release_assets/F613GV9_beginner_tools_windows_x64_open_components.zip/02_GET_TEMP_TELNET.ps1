﻿$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot

$factoryTool = Join-Path $PSScriptRoot 'go_build_zte_go.exe'
if (-not (Test-Path -LiteralPath $factoryTool)) {
    throw '缺少 go_build_zte_go.exe。请先阅读 README_FIRST.md，从可信社区来源取得并核对SHA256，再放入本文件夹。'
}

Write-Host ''
Write-Host '请选择网线直连光猫、状态为 Up 的有线网卡。' -ForegroundColor Cyan
Get-NetAdapter | Format-Table Name, Status, MacAddress, LinkSpeed -AutoSize

$macInput = Read-Host '请输入该有线网卡的 MAC 地址（横线可保留）'
$mac = ($macInput -replace '[-:\s]', '').ToLowerInvariant()
if ($mac -notmatch '^[0-9a-f]{12}$') {
    throw 'MAC格式错误：应为12个十六进制字符，例如 AABBCCDDEEFF。'
}

$superUser = Read-Host '请输入光猫超管用户名；直接回车使用移动常见值 CMCCAdmin'
if ([string]::IsNullOrWhiteSpace($superUser)) {
    $superUser = 'CMCCAdmin'
}
$securePass = Read-Host '请输入光猫超管密码（输入时不会显示）' -AsSecureString
$plainPass = [Net.NetworkCredential]::new('', $securePass).Password

Write-Host ''
Write-Host '正在请求FactoryMode。窗口A中的HTTPS兼容代理必须保持运行。' -ForegroundColor Cyan
try {
    & $factoryTool -addr 'http://127.0.0.1:18080' -mac $mac -username $superUser -password $plainPass
    $toolExit = $LASTEXITCODE
} finally {
    $plainPass = $null
    $securePass = $null
}

Write-Host ''
$portOpen = Test-NetConnection 192.168.1.1 -Port 23 -InformationLevel Quiet
if ($toolExit -eq 0 -and $portOpen) {
    Write-Host '成功：工具完成，并且光猫23端口已经开放。' -ForegroundColor Green
    Write-Host '记下上方临时Telnet用户名和密码，然后双击 03_OPEN_PUTTY.cmd。' -ForegroundColor Green
} else {
    Write-Host "未完成：工具退出码=$toolExit，23端口开放=$portOpen。" -ForegroundColor Red
    Write-Host '不要继续固化；检查真实有线MAC、超管密码和窗口A。' -ForegroundColor Yellow
}

Read-Host '按回车关闭本窗口'
if ($toolExit -ne 0 -or -not $portOpen) {
    exit 1
}

