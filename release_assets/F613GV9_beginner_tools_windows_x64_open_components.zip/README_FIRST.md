# F613GV9 Windows新手工具包（开源组件版）

这个包包含：本项目HTTPS兼容代理、官方PuTTY和中文操作脚本。

由于 `go_build_zte_go.exe` 没有公开源码、数字签名或已确认的再分发许可证，本包不替第三方重新分发它。请从你信任的原社区来源自行取得，并核对哈希：

```text
文件名：go_build_zte_go.exe
SHA256：7D8ABF5FDCCE9E57A6C0939C91952DC1C706DB81C15FA5F9B42A8B299C947339
```

把核对后的 `go_build_zte_go.exe` 放进本文件夹，与 `02_GET_TEMP_TELNET.cmd` 同级。

## 双击顺序

1. `00_SHOW_MAC.cmd`；
2. `01_START_PROXY.cmd`，窗口保持打开；
3. `02_GET_TEMP_TELNET.cmd`；
4. 工具成功且23端口开放后，双击 `03_OPEN_PUTTY.cmd`。

严格按顺序，不要四个一起双击。

本包还附带 `04_EXPERIMENTAL_OPEN_CLIENT.cmd`：它运行本项目新写的F613GV9专用开源客户端，不依赖第三方闭源工具。该客户端已通过公开协议、真实44字节响应和离线测试，但尚未在下一次拔纤维护窗口完成最终实机验证，因此默认教程暂不把它当作已验证主路线。

