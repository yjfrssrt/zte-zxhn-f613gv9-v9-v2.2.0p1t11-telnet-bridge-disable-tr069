# Third-party notices

## PuTTY 0.85 x64

- Project: https://www.chiark.greenend.org.uk/~sgtatham/putty/
- Download: https://the.earth.li/~sgtatham/putty/0.85/w64/putty.exe
- Licence: MIT; full notice in `PUTTY_LICENSE.txt`.
- PuTTY and its authors are not affiliated with this project.

## go_build_zte_go.exe

This file is not included. The tested community binary was unsigned, had no public source attached, and had no identified redistribution licence. Readers who independently obtain it can compare SHA-256 with the value recorded in `README_FIRST.md`.

Original community discussion/download-navigation page:

https://www.right.com.cn/forum/thread-8461781-15-1.html
